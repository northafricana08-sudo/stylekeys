# StyleKeys — Android keyboard project

A native Android keyboard (IME) and theme studio inspired by the fluffy blue-and-pink reference.

## Included in this upgraded build
- **36 built-in themes** across pastel, dark, nature, warm and all-theme galleries.
- Theme picker with live preview and persistent selection.
- Optional photo background picker (selected image URI is saved locally and used as a translucent keyboard backdrop).
- QWERTY layout, shift, numbers/symbols toggle, backspace, space, punctuation and enter/action key.
- Quick emoji strip with common emoji.
- No Internet permission, analytics or account requirement. Text is entered through Android's standard input framework; this app contains no code to transmit typed text.

## Build the APK
This is the complete Android Studio project source, **not a precompiled APK**.
1. Install Android Studio with Android SDK Platform 35.
2. Open this folder in Android Studio and let Gradle sync.
3. Select **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
4. Debug APK output: `app/build/outputs/apk/debug/app-debug.apk`.

Command-line build (on a machine with Android SDK and Gradle configured):
`gradle assembleDebug`

## Install and activate
1. Install the generated APK on your Android phone.
2. Open **StyleKeys** → **Enable StyleKeys keyboard**.
3. Enable **StyleKeys Keyboard** in Android settings.
4. Return to StyleKeys → **Switch to StyleKeys** and select it in the keyboard picker.
5. Choose a theme. Your selection is applied by the keyboard service.

## Important limitations
- This starter project does not yet include a downloadable GIF/sticker catalog, cloud theme store, custom font installation, keypress sounds, predictive text, swipe typing or multilingual dictionaries.
- The emoji strip is a small built-in set, not a full emoji browser.
- Android displays a system warning when enabling third-party keyboards. Review keyboard permissions and privacy before enabling any third-party IME.


## Build from your phone using GitHub Actions (no laptop required)
This project includes `.github/workflows/android-build.yml` for a cloud build.
1. On your phone, sign in to GitHub and create a **new public or private repository** named `StyleKeys`.
2. In the repository, use **Add file → Upload files** (you may need your browser's Desktop site mode) and upload the extracted project contents, including the hidden `.github` folder and its workflow file. Do not upload the ZIP itself as the only repository file.
3. Commit the files to the `main` branch.
4. Open the repository's **Actions** tab and select **Build StyleKeys APK**. If prompted, enable workflows, then run the workflow.
5. When the run finishes successfully, open that run, scroll to **Artifacts**, and download `StyleKeys-debug-apk`. Extract it on your phone and tap the APK to install.
6. Android may ask you to allow installs from the browser or file manager you used. Only allow this for the APK you built from your own repository, then turn the permission off again if you prefer.

The cloud build runs on GitHub's hosted build machine; your phone is only used to upload the source and download the APK.
