package com.stylekeys.keyboard

data class KeyTheme(val id:String,val name:String,val background:Int,val key:Int,val accent:Int,val text:Int,val emoji:String,val subtitle:String)

object Themes {
    val all = listOf(
        KeyTheme("cotton", "Cotton Candy", 0xFF789BEA.toInt(), 0xFFFFC2DC.toInt(), 0xFF5D7FD2.toInt(), 0xFF26345A.toInt(), "🧸", "Fluffy blue & pink"),
        KeyTheme("rose", "Rose Quartz", 0xFFFFDDE8.toInt(), 0xFFFFF4F7.toInt(), 0xFFE98EAE.toInt(), 0xFF713C55.toInt(), "🌸", "Soft romantic pink"),
        KeyTheme("lavender", "Lavender Dream", 0xFFB9A8E8.toInt(), 0xFFF0EAFE.toInt(), 0xFF9278D0.toInt(), 0xFF43365F.toInt(), "🦄", "Pastel purple"),
        KeyTheme("ocean", "Ocean Glow", 0xFF155E89.toInt(), 0xFFB9E9F8.toInt(), 0xFF2E9DC4.toInt(), 0xFF123D59.toInt(), "🌊", "Fresh aqua blue"),
        KeyTheme("midnight", "Midnight", 0xFF171B31.toInt(), 0xFF303957.toInt(), 0xFF8C9EFF.toInt(), 0xFFF5F6FF.toInt(), "🌙", "Dark and elegant"),
        KeyTheme("mint", "Mint Macaron", 0xFFBCE9D8.toInt(), 0xFFF1FFF8.toInt(), 0xFF76C9A9.toInt(), 0xFF285B4A.toInt(), "🍃", "Cool mint green"),
        KeyTheme("sunset", "Peach Sunset", 0xFFFFB58F.toInt(), 0xFFFFE4D5.toInt(), 0xFFFF8E68.toInt(), 0xFF713F30.toInt(), "🍑", "Warm peach tones"),
        KeyTheme("lemon", "Lemon Pop", 0xFFFFE77A.toInt(), 0xFFFFF9D8.toInt(), 0xFFEBC64E.toInt(), 0xFF65551A.toInt(), "🍋", "Sunny yellow"),
        KeyTheme("neon", "Neon Nights", 0xFF16152A.toInt(), 0xFF30264B.toInt(), 0xFFDA55FF.toInt(), 0xFFFFF4FF.toInt(), "⚡", "Electric purple"),
        KeyTheme("cloud", "Cloud White", 0xFFE9EEF7.toInt(), 0xFFFFFFFF.toInt(), 0xFFB8C8E5.toInt(), 0xFF34415A.toInt(), "☁️", "Clean minimal"),
        KeyTheme("cherry", "Cherry Crush", 0xFF9D2447.toInt(), 0xFFFFD5DF.toInt(), 0xFFE95D83.toInt(), 0xFF5D1930.toInt(), "🍒", "Bold cherry pink"),
        KeyTheme("gold", "Golden Luxe", 0xFF33291D.toInt(), 0xFFF1D9A5.toInt(), 0xFFC49A4A.toInt(), 0xFF4A371A.toInt(), "✨", "Warm gold & black"),
        KeyTheme("sky", "Baby Sky", 0xFFA9D9FF.toInt(), 0xFFEAF7FF.toInt(), 0xFF79B9EE.toInt(), 0xFF234C70.toInt(), "🩵", "Airy baby blue"),
        KeyTheme("berry", "Berry Milk", 0xFF8F477A.toInt(), 0xFFFFE1F2.toInt(), 0xFFEBA5D2.toInt(), 0xFF633653.toInt(), "🍓", "Sweet berry cream"),
        KeyTheme("butter", "Buttercream", 0xFFFFE7A6.toInt(), 0xFFFFF8E5.toInt(), 0xFFEBC66F.toInt(), 0xFF66502B.toInt(), "🧈", "Creamy warm neutral"),
        KeyTheme("sage", "Sage Garden", 0xFF8CA58D.toInt(), 0xFFE6EFE2.toInt(), 0xFFB6C9A8.toInt(), 0xFF344D3B.toInt(), "🌿", "Calm botanical"),
        KeyTheme("lilac", "Lilac Haze", 0xFF9F8CCB.toInt(), 0xFFEDE6FF.toInt(), 0xFFC4B3F0.toInt(), 0xFF4A3E68.toInt(), "💜", "Gentle lilac"),
        KeyTheme("coral", "Coral Kiss", 0xFFED927F.toInt(), 0xFFFFE2D9.toInt(), 0xFFFFB1A1.toInt(), 0xFF713D35.toInt(), "🪸", "Bright coral"),
        KeyTheme("mocha", "Mocha Mousse", 0xFF725448.toInt(), 0xFFE9D7C8.toInt(), 0xFFC49A7D.toInt(), 0xFF49372E.toInt(), "☕", "Coffee-house neutral"),
        KeyTheme("ice", "Arctic Ice", 0xFF91C9D8.toInt(), 0xFFEAFBFF.toInt(), 0xFFB9E8F2.toInt(), 0xFF28515B.toInt(), "🧊", "Cool icy blue"),
        KeyTheme("plum", "Plum Velvet", 0xFF4B284D.toInt(), 0xFFE8D2E8.toInt(), 0xFFB77BB8.toInt(), 0xFF4B284D.toInt(), "🍇", "Rich velvet purple"),
        KeyTheme("flamingo", "Flamingo", 0xFFEE8EAD.toInt(), 0xFFFFE1EA.toInt(), 0xFFFFB6CC.toInt(), 0xFF71354C.toInt(), "🦩", "Playful pink"),
        KeyTheme("denim", "Denim Blue", 0xFF345B8D.toInt(), 0xFFD8E7FA.toInt(), 0xFF8FB5E8.toInt(), 0xFF203B60.toInt(), "👖", "Classic blue"),
        KeyTheme("matcha", "Matcha Latte", 0xFF84965B.toInt(), 0xFFE8EBCB.toInt(), 0xFFBEC98A.toInt(), 0xFF48532D.toInt(), "🍵", "Earthy green"),
        KeyTheme("rainbow", "Rainbow Pop", 0xFF7D83D8.toInt(), 0xFFFFD5E8.toInt(), 0xFFFFD98C.toInt(), 0xFF493B72.toInt(), "🌈", "Colourful pastel"),
        KeyTheme("honey", "Honey Bee", 0xFFB77A22.toInt(), 0xFFFFE5A8.toInt(), 0xFFFFC95C.toInt(), 0xFF664316.toInt(), "🐝", "Golden honey"),
        KeyTheme("sakura", "Sakura", 0xFFEAADC8.toInt(), 0xFFFFF0F6.toInt(), 0xFFF5C9DD.toInt(), 0xFF704357.toInt(), "🌸", "Cherry blossom"),
        KeyTheme("aurora", "Aurora", 0xFF244C68.toInt(), 0xFFCDEBE5.toInt(), 0xFF9FC9D9.toInt(), 0xFF24465B.toInt(), "🌌", "Northern lights"),
        KeyTheme("graphite", "Graphite", 0xFF282C34.toInt(), 0xFFE1E5EA.toInt(), 0xFF9DA7B3.toInt(), 0xFF252B33.toInt(), "🖤", "Modern monochrome"),
        KeyTheme("cocoa", "Cocoa", 0xFF60483F.toInt(), 0xFFE9D2BE.toInt(), 0xFFC7A58A.toInt(), 0xFF49352E.toInt(), "🍫", "Chocolate cream"),
        KeyTheme("tangerine", "Tangerine", 0xFFDD7A32.toInt(), 0xFFFFE0BD.toInt(), 0xFFFFB36B.toInt(), 0xFF713D1E.toInt(), "🍊", "Citrus orange"),
        KeyTheme("periwinkle", "Periwinkle", 0xFF7586C8.toInt(), 0xFFE4E9FF.toInt(), 0xFFB9C5FF.toInt(), 0xFF38456F.toInt(), "🪻", "Blue violet"),
        KeyTheme("seafoam", "Seafoam", 0xFF4E9F98.toInt(), 0xFFD8F4ED.toInt(), 0xFF9EDCCB.toInt(), 0xFF285C57.toInt(), "🐚", "Sea glass green"),
        KeyTheme("ruby", "Ruby Red", 0xFF7C243C.toInt(), 0xFFFFDCE2.toInt(), 0xFFE98A9C.toInt(), 0xFF5A1D2D.toInt(), "❤️", "Ruby and blush"),
        KeyTheme("cosmic", "Cosmic", 0xFF242044.toInt(), 0xFF443C72.toInt(), 0xFFB7A4FF.toInt(), 0xFFF6F1FF.toInt(), "🪐", "Deep space purple"),
        KeyTheme("vanilla", "Vanilla Sky", 0xFFD9C8A8.toInt(), 0xFFFFF8E8.toInt(), 0xFFE7D9B9.toInt(), 0xFF5B4B35.toInt(), "🤍", "Soft vanilla"),
    )
    fun get(id:String?) = all.firstOrNull { it.id == id } ?: all.first()
}
