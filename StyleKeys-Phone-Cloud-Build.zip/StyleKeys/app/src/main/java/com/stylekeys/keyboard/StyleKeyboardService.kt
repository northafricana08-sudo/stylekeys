package com.stylekeys.keyboard

import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.inputmethodservice.InputMethodService
import android.view.Gravity
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.LinearLayout
import android.widget.TextView

class StyleKeyboardService : InputMethodService() {
    private var shifted = false
    private var symbols = false
    private val theme get() = Themes.get(getSharedPreferences("stylekeys", MODE_PRIVATE).getString("theme", "cotton"))

    override fun onCreateInputView(): View {
        val t = theme
        val prefs = getSharedPreferences("stylekeys", MODE_PRIVATE)
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(4, 7, 4, 7)
            setBackgroundColor(t.background)
        }
        val customUri = prefs.getString("background_uri", null)
        if (customUri != null) {
            try {
                val bmp = contentResolver.openInputStream(android.net.Uri.parse(customUri))?.use { android.graphics.BitmapFactory.decodeStream(it) }
                if (bmp != null) panel.background = android.graphics.drawable.BitmapDrawable(resources, android.graphics.Bitmap.createScaledBitmap(bmp, 900, 380, true)).apply { alpha = 105 }
            } catch (_: Exception) {}
        }
        val first = if (symbols) "1234567890" else if (shifted) "QWERTYUIOP" else "qwertyuiop"
        val second = if (symbols) "@#$%&-*+()" else if (shifted) "ASDFGHJKL" else "asdfghjkl"
        val third = if (symbols) "!?.,:;'/\"" else if (shifted) "ZXCVBNM" else "zxcvbnm"
        addRow(panel, first, t)
        addRow(panel, second, t, 0.45f)
        val row3 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        addKey(row3, if (shifted) "⇧" else "⬆", t, 1.25f) { shifted = !shifted; refresh() }
        third.forEach { ch -> addKey(row3, ch.toString(), t, 1f) { commit(ch.toString()) } }
        addKey(row3, "⌫", t, 1.25f) { currentInputConnection?.deleteSurroundingText(1, 0) }
        panel.addView(row3, rowParams())
        val bottom = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        addKey(bottom, if (symbols) "ABC" else "?123", t, 1.25f) { symbols = !symbols; refresh() }
        addKey(bottom, "☺", t, 0.9f) { showEmojiRow(panel, t) }
        addKey(bottom, ",", t, 0.65f) { commit(",") }
        addKey(bottom, "English", t, 3.6f) { commit(" ") }
        addKey(bottom, ".", t, 0.65f) { commit(".") }
        addKey(bottom, "↵", t, 1.25f) {
            val action = currentInputEditorInfo?.imeOptions?.and(EditorInfo.IME_MASK_ACTION) ?: EditorInfo.IME_ACTION_NONE
            if (action != EditorInfo.IME_ACTION_NONE) currentInputConnection?.performEditorAction(action) else commit("\n")
        }
        panel.addView(bottom, rowParams())
        return panel
    }

    private fun showEmojiRow(panel: LinearLayout, t: KeyTheme) {
        val emojis = listOf("❤️","😂","🥰","😍","😘","✨","🔥","😭","😊","💕","🌸","🦋","💖","🙌")
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        emojis.take(7).forEach { emoji -> addKey(row, emoji, t, 1f) { commit(emoji) } }
        panel.addView(row, 42)
        val row2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        emojis.drop(7).forEach { emoji -> addKey(row2, emoji, t, 1f) { commit(emoji) } }
        panel.addView(row2, 42)
    }

    private fun addRow(panel: LinearLayout, chars: String, t: KeyTheme, inset: Float = 0f) {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        if (inset > 0) row.addView(View(this), LinearLayout.LayoutParams(0, 1, inset))
        chars.forEach { ch -> addKey(row, ch.toString(), t, 1f) { commit(ch.toString()) } }
        if (inset > 0) row.addView(View(this), LinearLayout.LayoutParams(0, 1, inset))
        panel.addView(row, rowParams())
    }
    private fun rowParams() = LinearLayout.LayoutParams(-1, 46).apply { setMargins(0, 3, 0, 3) }
    private fun addKey(row: LinearLayout, label: String, t: KeyTheme, weight: Float, action: () -> Unit) {
        val v = TextView(this).apply {
            text = label; textSize = if (label.length > 2) 11f else 19f
            gravity = Gravity.CENTER; setTextColor(t.text)
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            background = GradientDrawable().apply {
                setColor(if (label == "↵" || label == "⇧" || label == "⬆" || label == "⌫" || label == "?123" || label == "ABC") t.accent else t.key)
                cornerRadius = 12f
                setStroke(1, adjustAlpha(t.text, 0.10f))
            }
            isClickable = true; setOnClickListener { action() }
        }
        row.addView(v, LinearLayout.LayoutParams(0, -1, weight).apply { setMargins(2, 0, 2, 0) })
    }
    private fun adjustAlpha(color: Int, factor: Float) = Color.argb((Color.alpha(color) * factor).toInt(), Color.red(color), Color.green(color), Color.blue(color))
    private fun commit(value: String) { currentInputConnection?.commitText(value, 1) }
    private fun refresh() { setInputView(onCreateInputView()) }
}
