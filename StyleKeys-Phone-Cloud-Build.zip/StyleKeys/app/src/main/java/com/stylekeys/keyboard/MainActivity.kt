package com.stylekeys.keyboard

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.inputmethod.InputMethodManager
import android.widget.*

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("stylekeys", MODE_PRIVATE) }
    private lateinit var preview: TextView
    private lateinit var selectedLabel: TextView
    private var chosenCategory = "All"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(25, 29, 55)
        window.navigationBarColor = Color.rgb(25, 29, 55)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 22, 18, 18)
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.rgb(25, 29, 55), Color.rgb(75, 76, 145)))
        }
        root.addView(TextView(this).apply {
            text = "✦  StyleKeys"; textSize = 30f; setTextColor(Color.WHITE)
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
        })
        root.addView(TextView(this).apply {
            text = "Make every message feel like you."; textSize = 14f
            setTextColor(0xFFDDE4FF.toInt()); setPadding(0, 3, 0, 14)
        })
        preview = TextView(this).apply {
            text = "  hello beautiful  ♡  123  ✨  \\n  The quick brown fox jumps over  "
            textSize = 17f; gravity = Gravity.CENTER; setPadding(12, 18, 12, 18)
        }
        root.addView(preview)
        selectedLabel = TextView(this).apply {
            textSize = 14f; setTextColor(Color.WHITE); setPadding(0, 10, 0, 7)
        }
        root.addView(selectedLabel)

        val categoryScroll = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false }
        val categories = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf("All", "Pastel", "Dark", "Nature", "Warm").forEach { cat ->
            val b = TextView(this).apply {
                text = cat; textSize = 13f; gravity = Gravity.CENTER
                setTextColor(Color.WHITE); setPadding(16, 9, 16, 9)
                background = rounded(if (cat == chosenCategory) 0xFF7189D9.toInt() else 0x443B477A, 30)
                setOnClickListener { chosenCategory = cat; refreshThemes(gridContainer) ; refreshCategories(categories) }
            }
            categories.addView(b, LinearLayout.LayoutParams(-2, -2).apply { setMargins(0, 0, 7, 0) })
        }
        categoryScroll.addView(categories)
        root.addView(categoryScroll)

        val scroll = ScrollView(this)
        gridContainer = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(gridContainer)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        root.addView(actionButton("＋  Choose a photo background").apply {
            setOnClickListener {
                val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE); type = "image/*"
                }
                startActivityForResult(intent, 42)
            }
        })
        root.addView(actionButton("1. Enable StyleKeys keyboard").apply {
            setOnClickListener { startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)) }
        })
        root.addView(actionButton("2. Switch to StyleKeys").apply {
            setOnClickListener {
                (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()
            }
        })
        root.addView(TextView(this).apply {
            text = "Private by design • Your typing stays on your device"
            textSize = 11f; gravity = Gravity.CENTER; setTextColor(0xFFDDE4FF.toInt())
            setPadding(0, 9, 0, 0)
        })
        setContentView(root)
        choose(Themes.get(prefs.getString("theme", "cotton")))
        refreshThemes(gridContainer)
    }

    private lateinit var gridContainer: LinearLayout

    private fun refreshCategories(container: LinearLayout) {
        // Category selection is reflected when the gallery is refreshed.
        container.removeAllViews()
        listOf("All", "Pastel", "Dark", "Nature", "Warm").forEach { cat ->
            container.addView(TextView(this).apply {
                text = cat; textSize = 13f; gravity = Gravity.CENTER
                setTextColor(Color.WHITE); setPadding(16, 9, 16, 9)
                background = rounded(if (cat == chosenCategory) 0xFF7189D9.toInt() else 0x443B477A, 30)
                setOnClickListener { chosenCategory = cat; refreshThemes(gridContainer); refreshCategories(container) }
            }, LinearLayout.LayoutParams(-2, -2).apply { setMargins(0, 0, 7, 0) })
        }
    }

    private fun refreshThemes(container: LinearLayout) {
        container.removeAllViews()
        val filtered = Themes.all.filter { t ->
            when (chosenCategory) {
                "Pastel" -> t.id in listOf("cotton","rose","lavender","sky","berry","butter","lilac","flamingo","sakura","periwinkle","vanilla")
                "Dark" -> t.id in listOf("midnight","neon","plum","graphite","cosmic","gold")
                "Nature" -> t.id in listOf("mint","sage","matcha","seafoam","ocean","ice","aurora")
                "Warm" -> t.id in listOf("sunset","lemon","cherry","gold","honey","coral","mocha","cocoa","tangerine","ruby")
                else -> true
            }
        }
        filtered.chunked(2).forEach { pair ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            pair.forEach { theme ->
                val tile = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
                    setPadding(8, 9, 8, 9); background = rounded(theme.key, 20)
                    layoutParams = LinearLayout.LayoutParams(0, 104, 1f).apply { setMargins(4, 4, 4, 4) }
                    setOnClickListener { choose(theme) }
                }
                tile.addView(TextView(this).apply { text = theme.emoji; textSize = 24f; gravity = Gravity.CENTER; setTextColor(theme.text) })
                tile.addView(TextView(this).apply {
                    text = theme.name; textSize = 13f; gravity = Gravity.CENTER
                    setTextColor(theme.text); typeface = Typeface.DEFAULT_BOLD
                })
                tile.addView(TextView(this).apply { text = theme.subtitle; textSize = 9f; gravity = Gravity.CENTER; setTextColor(theme.text) })
                row.addView(tile)
            }
            if (pair.size == 1) row.addView(Space(this), LinearLayout.LayoutParams(0, 1, 1f))
            container.addView(row)
        }
    }

    private fun choose(theme: KeyTheme) {
        prefs.edit().putString("theme", theme.id).apply()
        selectedLabel.text = "Selected: ${theme.emoji}  ${theme.name}"
        preview.setTextColor(theme.text)
        preview.background = rounded(theme.key, 22)
    }
    private fun actionButton(label: String) = Button(this).apply {
        text = label; isAllCaps = false; textSize = 14f
        setTextColor(Color.WHITE); background = rounded(0xFF536FC1.toInt(), 18)
        layoutParams = LinearLayout.LayoutParams(-1, 50).apply { setMargins(0, 5, 0, 0) }
    }
    private fun rounded(color: Int, radius: Int) = GradientDrawable().apply {
        setColor(color); cornerRadius = radius.toFloat()
    }

    @Deprecated("Deprecated in Android API")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 42 && resultCode == RESULT_OK) {
            data?.data?.let { uri: Uri ->
                try {
                    contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                } catch (_: Exception) {}
                prefs.edit().putString("background_uri", uri.toString()).apply()
                Toast.makeText(this, "Photo saved as your keyboard background", Toast.LENGTH_LONG).show()
            }
        }
    }
}
